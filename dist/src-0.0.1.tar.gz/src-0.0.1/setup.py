from setuptools import setup, find_packages

setup(
    name="src",
    version = "0.0.1",
    description = "This is Wine Quality package",
    author = "the amazing Aymane",
    package =find_packages(),
    licence = "MIT",
)